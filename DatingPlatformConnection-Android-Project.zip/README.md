# Dating Platform Connection — Android starter project

This is a free starter Android app project with a simple dating-profile interface. It is designed to be built into an APK using a free cloud build from your Android phone.

## Included
- Android WebView app wrapper
- Discover screen with demo profiles
- Like/unlike and liked-profiles list
- Local profile form saved on the device
- Responsive layout and basic safety reminders

## Important limitations
This is a prototype, not yet a complete public dating service. Sample profiles are not real people. It does not include server-side accounts, online profile uploads, real-time matching, private messaging, moderation, or secure backend storage. Do not publish it as a functioning matchmaking service until those features, privacy terms, age controls, reporting/blocking, and security are implemented.

## Build the APK using only your Android phone (free route)
1. Download and extract this ZIP on your phone.
2. Sign in to GitHub or create a free account.
3. Create a new repository, for example `dating-platform-connection`.
4. Upload the *contents* of this folder to the repository (not just the ZIP). Keep the `.github/workflows/build-apk.yml` file and its folder.
5. Open the repository's **Actions** tab and enable Actions if prompted.
6. The workflow named **Build Android APK** should run after upload. If it does not, open Actions and manually run it.
7. Open the completed workflow run, scroll to **Artifacts**, and download `DatingPlatformConnection-debug-apk`.
8. Extract the downloaded artifact ZIP and tap the APK to install. Android may ask you to allow installs from that browser/file app. Only install APKs you built and trust.

## If the build fails
Open the workflow run and read the first red error. Check that the uploaded repository includes `settings.gradle`, `build.gradle`, `gradle.properties`, `app/`, and `.github/workflows/build-apk.yml`.

## Customize before sharing
Edit `app/src/main/assets/index.html` to change sample profiles, colours, text, or WhatsApp contact. The current WhatsApp button is deliberately a reminder and does not message anyone.
